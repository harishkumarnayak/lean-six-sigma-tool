# Deployment Guide for Lean Six Sigma Analysis Tool

This guide provides step-by-step instructions for deploying the Lean Six Sigma Analysis Tool to your Hostinger web hosting server and integrating it with your existing website.

## Overview

The Lean Six Sigma Analysis Tool is packaged as `lean-six-sigma-analysis-tool.tar.gz`. This contains everything needed to run the application. The deployment method depends on whether your Hostinger plan supports Node.js.

## Deployment Options

### Option 1: Deploy to Hostinger with Node.js Support

If your Hostinger plan includes Node.js support:

1. **Download the package**:
   - Download the `lean-six-sigma-analysis-tool.tar.gz` file to your computer
   - Extract the contents to a local folder

2. **Upload to your server**:
   - Log in to your Hostinger Control Panel
   - Navigate to File Manager (or use FTP)
   - Create a new directory in your public_html folder called `tools`
   - Upload all the extracted files to this directory

3. **Set up Node.js**:
   - In Hostinger Control Panel, navigate to "Advanced" > "Node.js"
   - Create a new Node.js application with these settings:
     - Directory: `/public_html/tools`
     - Startup File: `server/index.ts`
     - Node.js Version: 16 or higher
     - Environment Variables: Add `GOOGLE_API_KEY=your_api_key_here`
   - Save the configuration

4. **Install dependencies and start**:
   - Connect to your server via SSH (if available in your Hostinger plan)
   - Navigate to your tools directory (`cd public_html/tools`)
   - Run these commands:
     ```
     npm install
     npm run dev
     ```
   - If SSH access isn't available, use Hostinger's Node.js interface to install and run

5. **Access your application**:
   - Your tool will be available at: `https://yourdomain.com/tools`

### Option 2: Deploy as Static HTML/JavaScript (No Node.js support)

If your Hostinger plan doesn't support Node.js:

1. **Set up a development environment**:
   - On your local computer, install Node.js (if not already installed)
   - Extract the package contents
   - Install dependencies and build the application:
     ```
     npm install
     npm run build
     ```
   - This creates a `dist` folder with static files

2. **Upload to your Hostinger server**:
   - Upload the contents of the `dist` folder to a `tools` directory on your server
   - Make sure to include the `.htaccess` file

3. **Create a serverless function for the API**:
   - Since static hosting won't run your Node.js backend, you'll need a serverless function
   - Options include:
     - Vercel Functions
     - AWS Lambda
     - Google Cloud Functions
   - Deploy the API code (`server/gemini-updated.ts`) to your chosen serverless platform
   - Update the API endpoint in `client/src/lib/api.ts` to point to your serverless function URL

4. **Configure your API keys**:
   - Add your Google Gemini API key to your serverless function's environment variables

### Option 3: Embed via iframe (Easiest option)

The simplest method to integrate with your existing website:

1. **Deploy the full application** to a Node.js hosting service:
   - Options include Vercel, Render, Railway, or similar platforms
   - Follow their deployment instructions using the provided files
   - Make sure to set your Google API key in their environment variables

2. **Add an iframe to your existing website**:
   - Edit your website's HTML where you want to add the tool
   - Add this iframe code:
     ```html
     <iframe 
       src="https://your-deployed-app-url.com" 
       style="width:100%; height:800px; border:none;"
       title="Lean Six Sigma Analysis Tool">
     </iframe>
     ```
   - Replace `your-deployed-app-url.com` with the URL where you deployed the tool

## Testing Your Deployment

After deploying, test the application by:

1. Navigating to your tool page
2. Filling out the analysis form with a sample problem
3. Verifying that the analysis generates correctly
4. Checking that the results display properly

## Troubleshooting

- **API errors**: Verify your Google API key is correctly set
- **404 errors**: Make sure routing is properly configured
- **Page not loading**: Check your browser's developer console for errors
- **Integration issues**: Ensure paths and URLs are correctly set

## Additional Resources

- [Hostinger Node.js Hosting Guide](https://www.hostinger.com/tutorials/how-to-host-node-js-application)
- [Google Gemini API Documentation](https://ai.google.dev/docs/gemini_api)

If you need further assistance, feel free to reach out for help.