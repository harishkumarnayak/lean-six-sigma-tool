/**
 * Lean Six Sigma Analysis Tool - Setup Script
 * 
 * This script helps you set up the application for deployment.
 * Run this script after downloading the package to configure your environment.
 */

const readline = require('readline');
const fs = require('fs');
const path = require('path');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log('\n===== Lean Six Sigma Analysis Tool - Setup =====\n');
console.log('This script will help you configure the application for deployment.');
console.log('Please answer the following questions to set up your environment.\n');

function askQuestions(questionIndex = 0) {
  const questions = [
    {
      question: 'Do you have Node.js installed on your server? (yes/no)',
      handler: (answer) => {
        if (answer.toLowerCase() === 'yes') {
          console.log('\nGreat! You can run this application using Node.js.');
          console.log('Follow these steps to deploy:');
          console.log('1. Upload all files to your server');
          console.log('2. Run "npm install" to install dependencies');
          console.log('3. Run "npm run build" to build the application');
          console.log('4. Run "npm start" to start the server');
          console.log('\nThe application will be available at http://your-domain/tools\n');
        } else {
          console.log('\nNo problem! You can use the static export method.');
          console.log('Follow these steps to deploy:');
          console.log('1. On your development machine (not the server), run:');
          console.log('   - npm install');
          console.log('   - npm run build');
          console.log('2. Copy the contents of the "dist" folder to your server');
          console.log('3. Configure your web server to serve these static files');
          console.log('\nThe application will be available at http://your-domain/tools\n');
        }
        askQuestions(questionIndex + 1);
      }
    },
    {
      question: 'Would you like to set up your Google Gemini API key now? (yes/no)',
      handler: (answer) => {
        if (answer.toLowerCase() === 'yes') {
          rl.question('\nEnter your Google Gemini API key: ', (apiKey) => {
            if (apiKey.trim()) {
              console.log('\nAPI key will be saved to your deployment configuration.');
              generateConfigFiles(apiKey.trim());
            } else {
              console.log('\nNo API key provided. You will need to add it later.');
              generateConfigFiles('YOUR_GOOGLE_API_KEY');
            }
            askQuestions(questionIndex + 1);
          });
        } else {
          console.log('\nYou can add your API key later in the .env file.');
          generateConfigFiles('YOUR_GOOGLE_API_KEY');
          askQuestions(questionIndex + 1);
        }
      }
    },
    {
      question: 'Would you like to integrate with your existing database? (yes/no)',
      handler: (answer) => {
        if (answer.toLowerCase() === 'yes') {
          console.log('\nThe application supports PostgreSQL databases.');
          console.log('Edit the .env file to add your database connection string:');
          console.log('DATABASE_URL=postgresql://username:password@hostname:port/database');
        } else {
          console.log('\nThe application will use in-memory storage by default.');
          console.log('You can configure database integration later if needed.');
        }
        askQuestions(questionIndex + 1);
      }
    },
    {
      question: 'Press Enter to finish setup...',
      handler: () => {
        console.log('\n===== Setup Complete =====\n');
        console.log('Thank you for installing the Lean Six Sigma Analysis Tool!');
        console.log('If you need any assistance, please refer to the documentation.\n');
        rl.close();
      }
    }
  ];

  if (questionIndex >= questions.length) {
    return rl.close();
  }

  rl.question(questions[questionIndex].question + ' ', (answer) => {
    questions[questionIndex].handler(answer);
  });
}

function generateConfigFiles(apiKey) {
  // Create .env file
  const envContent = `# Environment Configuration
NODE_ENV=production
GOOGLE_API_KEY=${apiKey}
PORT=5000

# Uncomment and configure if using a database
# DATABASE_URL=postgresql://username:password@hostname:port/database
`;

  fs.writeFileSync(path.join(__dirname, '.env'), envContent);
  console.log('Created .env file with configuration.');

  // Create .htaccess file for SPA routing
  const htaccessContent = `# Handle SPA routing
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
`;

  fs.writeFileSync(path.join(__dirname, '.htaccess'), htaccessContent);
  console.log('Created .htaccess file for SPA routing.');
}

// Start the setup process
askQuestions();