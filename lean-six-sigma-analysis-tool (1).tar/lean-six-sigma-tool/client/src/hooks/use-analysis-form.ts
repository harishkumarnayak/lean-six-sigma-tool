import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { generateAnalysis } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export interface AnalysisFormData {
  mode: 'standard' | 'advanced';
  problemStatement: string;
  whenObserved: string;
  whereObserved: string;
  impacts: string;
  contributingFactors: string;
  knownRootCause: string;
}

const initialFormData: AnalysisFormData = {
  mode: 'standard',
  problemStatement: '',
  whenObserved: '',
  whereObserved: '',
  impacts: '',
  contributingFactors: '',
  knownRootCause: '',
};

export function useAnalysisForm() {
  const [formData, setFormData] = useState<AnalysisFormData>(initialFormData);
  const { toast } = useToast();

  // Define mutation for API call
  const {
    mutate,
    data: analysisResults,
    isPending: isLoading,
    isError,
    error
  } = useMutation({
    mutationFn: generateAnalysis,
    onSuccess: () => {
      toast({
        title: "Analysis Complete",
        description: "Your 5 Whys analysis has been generated successfully by Google Gemini AI.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to generate analysis with Google Gemini AI. Please try again.",
      });
    }
  });

  // Handle mode change
  const handleModeChange = (mode: 'standard' | 'advanced') => {
    setFormData(prev => ({ ...prev, mode }));
  };

  // Handle input change
  const handleInputChange = (field: keyof AnalysisFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Handle form submission
  const handleSubmit = () => {
    mutate(formData);
  };

  // Reset form
  const resetForm = () => {
    setFormData(initialFormData);
  };

  // Retry submission
  const retrySubmission = () => {
    mutate(formData);
  };

  // Prepare error message
  const errorMessage = isError 
    ? error instanceof Error 
      ? error.message 
      : "An unexpected error occurred. Please try again."
    : "";

  return {
    formData,
    isLoading,
    isError,
    errorMessage,
    analysisResults,
    handleModeChange,
    handleInputChange,
    handleSubmit,
    resetForm,
    retrySubmission
  };
}
