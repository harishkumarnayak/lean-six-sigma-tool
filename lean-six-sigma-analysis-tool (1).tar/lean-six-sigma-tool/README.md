# Lean Six Sigma Analysis Tool

## Overview

This application is an AI-powered Lean Six Sigma analysis tool focused on 5 Whys Root Cause Analysis and solution generation. Users can input problem details, and the application leverages Google Gemini to generate structured analysis and actionable solutions for process improvement.

## Features

- Interactive form for problem statement submission
- Standard and Advanced analysis modes
- 5 Whys root cause analysis generation
- Actionable solution recommendations
- Clean, modern user interface
- Mobile-responsive design

## Installation

1. Download and extract the `lean-six-sigma-analysis-tool.tar.gz` file
2. Follow the deployment instructions in `DEPLOYMENT_GUIDE.md` based on your hosting environment
3. Configure your Google Gemini API key as directed in the guide

## Quick Start

### Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

### Environment Variables

Create a `.env` file with the following variables:

```
GOOGLE_API_KEY=your_api_key_here
NODE_ENV=production
PORT=5000
```

## Integration with Your Website

You can integrate this tool with your existing website in several ways:

1. **Full Application Integration**: Deploy the complete application and link to it from your main site
2. **Iframe Embedding**: Use an iframe to embed the tool within an existing page
3. **Static Files Approach**: Deploy the built static files to a subdirectory of your site

See `DEPLOYMENT_GUIDE.md` for detailed steps for each approach.

## Customization

You can customize the application to match your website's design by:

- Editing the themes in `client/src/index.css`
- Modifying the component styling in the UI components
- Changing logos and branding elements

## Support

If you need help with deployment or customization, please refer to the documentation or reach out for assistance.