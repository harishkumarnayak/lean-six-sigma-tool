import { Card, CardContent } from "@/components/ui/card";

export default function LoadingIndicator() {
  return (
    <Card className="bg-white rounded-lg shadow-sm">
      <CardContent className="p-10">
        <div className="flex flex-col items-center justify-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-primary mb-4"></div>
          <h3 className="text-xl font-medium text-primary mb-2">Generating Your Analysis</h3>
          <p className="text-slate-600 text-center max-w-md">
            Google Gemini AI is analyzing your problem, identifying root causes, and developing actionable solutions. This typically takes 20-30 seconds.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
