import { apiRequest } from "@/lib/queryClient";
import { AnalysisFormData } from "@/hooks/use-analysis-form";

// Function to generate analysis from the API
export async function generateAnalysis(formData: AnalysisFormData) {
  try {
    const response = await apiRequest('POST', '/api/analysis', formData);
    return await response.json();
  } catch (error) {
    console.error('Error generating analysis:', error);
    throw error;
  }
}
