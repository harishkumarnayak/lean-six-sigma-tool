import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateLeanSixSigmaAnalysis } from "./gemini-updated";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route for the 5 Whys analysis
  app.post('/api/analysis', async (req, res) => {
    try {
      const formData = req.body;
      
      if (!formData || !formData.problemStatement || !formData.whenObserved || 
          !formData.whereObserved || !formData.impacts) {
        return res.status(400).json({ 
          error: 'Missing required fields',
          message: 'Please provide all required information to generate the analysis.'
        });
      }

      // If advanced mode is selected, knownRootCause is required
      if (formData.mode === 'advanced' && !formData.knownRootCause) {
        return res.status(400).json({
          error: 'Missing known root cause',
          message: 'Please provide the known root cause for advanced mode analysis.'
        });
      }

      // Generate analysis using Google Gemini
      const analysisResult = await generateLeanSixSigmaAnalysis(formData);
      
      return res.status(200).json(analysisResult);
    } catch (error) {
      console.error('Error generating analysis:', error);
      return res.status(500).json({
        error: 'Analysis generation failed',
        message: error instanceof Error ? error.message : 'An unexpected error occurred'
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
