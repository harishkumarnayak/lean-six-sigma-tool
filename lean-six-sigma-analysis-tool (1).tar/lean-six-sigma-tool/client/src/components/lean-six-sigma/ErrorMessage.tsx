import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ErrorMessageProps {
  message: string;
  onRetry: () => void;
}

export default function ErrorMessage({ message, onRetry }: ErrorMessageProps) {
  return (
    <Card className="bg-white rounded-lg shadow-sm border border-red-200">
      <CardContent className="p-6">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            <i className="fas fa-exclamation-circle text-red-500 text-2xl"></i>
          </div>
          <div className="ml-3">
            <h3 className="text-lg font-medium text-red-800">Error Processing Your Request</h3>
            <div className="mt-2 text-sm text-red-700">
              {message || "We encountered a problem connecting to Google Gemini AI. Please try again or contact support if the issue persists."}
            </div>
            <div className="mt-4">
              <Button 
                onClick={onRetry} 
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Try Again
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
