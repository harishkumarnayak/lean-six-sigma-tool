import { Card, CardContent, CardHeader } from "@/components/ui/card";

export default function InfoSidebar() {
  return (
    <div className="space-y-6">
      <Card className="bg-white rounded-lg shadow-sm overflow-hidden">
        <CardHeader className="bg-primary text-white px-4 py-3">
          <h3 className="text-lg font-medium">About 5 Whys Analysis</h3>
        </CardHeader>
        <CardContent className="p-4">
          <div className="bg-blue-50 border-l-4 border-blue-400 p-3 mb-4 rounded">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-blue-500" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-2">
                <p className="text-xs text-blue-700 font-medium">Now powered by Google Gemini AI</p>
                <p className="text-xs text-blue-600">Enhanced analysis capabilities with Google's latest language model.</p>
              </div>
            </div>
          </div>
          <p className="text-sm text-slate-700 mb-4">
            The 5 Whys is a simple but powerful technique for cutting quickly through the outward symptoms of a problem to reveal its underlying causes, so that you can deal with it once and for all.
          </p>
          
          {/* Process improvement diagram as SVG */}
          <svg 
            viewBox="0 0 600 300" 
            className="w-full rounded-lg shadow-sm mb-4 bg-slate-50"
          >
            {/* Base circle layout */}
            <circle cx="100" cy="150" r="40" fill="#f0fdfa" stroke="#14b8a6" strokeWidth="2" />
            <circle cx="250" cy="150" r="40" fill="#f0f9ff" stroke="#0ea5e9" strokeWidth="2" />
            <circle cx="400" cy="150" r="40" fill="#ecfdf5" stroke="#10b981" strokeWidth="2" />
            <circle cx="550" cy="150" r="40" fill="#d1fae5" stroke="#047857" strokeWidth="2" />
            
            {/* Connecting arrows */}
            <path d="M145 150 H205" stroke="#0ea5e9" strokeWidth="2" markerEnd="url(#arrowhead)" />
            <path d="M295 150 H355" stroke="#10b981" strokeWidth="2" markerEnd="url(#arrowhead)" />
            <path d="M445 150 H505" stroke="#047857" strokeWidth="2" markerEnd="url(#arrowhead)" />
            
            {/* Arrow marker */}
            <defs>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#64748b" />
              </marker>
            </defs>
            
            {/* Circle labels */}
            <text x="100" y="155" textAnchor="middle" fill="#134e4a" fontSize="14">Problem</text>
            <text x="250" y="155" textAnchor="middle" fill="#0c4a6e" fontSize="14">Why?</text>
            <text x="400" y="155" textAnchor="middle" fill="#064e3b" fontSize="14">Why?</text>
            <text x="550" y="155" textAnchor="middle" fill="#064e3b" fontSize="14">Root Cause</text>
            
            {/* Process labels */}
            <text x="175" y="130" textAnchor="middle" fill="#64748b" fontSize="12">Analysis</text>
            <text x="325" y="130" textAnchor="middle" fill="#64748b" fontSize="12">Deeper Inquiry</text>
            <text x="475" y="130" textAnchor="middle" fill="#64748b" fontSize="12">Solution</text>
          </svg>
          
          <h4 className="font-medium text-primary mb-2">How It Works:</h4>
          <ol className="text-sm text-slate-700 mb-4 list-decimal pl-5 space-y-1">
            <li>State the problem clearly</li>
            <li>Ask "Why?" the problem occurs</li>
            <li>For each answer, ask "Why?" again</li>
            <li>Repeat at least 5 times until root cause is identified</li>
            <li>Develop solutions that address the root cause</li>
          </ol>
          
          <div className="flex justify-center">
            <a href="#" className="text-primary text-sm font-medium hover:text-primary/90 flex items-center">
              <span>Learn more about 5 Whys</span>
              <i className="fas fa-arrow-right ml-1"></i>
            </a>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white rounded-lg shadow-sm p-4">
        <h3 className="text-lg font-medium text-primary mb-3">Need More Tools?</h3>
        <ul className="space-y-3">
          <li>
            <a href="#" className="flex items-center p-3 rounded-lg hover:bg-slate-50 transition-colors">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-secondary/20 text-secondary flex items-center justify-center">
                <i className="fas fa-fish-fins"></i>
              </div>
              <div className="ml-3">
                <h4 className="text-sm font-medium text-slate-900">Fishbone Diagram Generator</h4>
                <p className="text-xs text-slate-500">Identify potential causes for an effect or problem</p>
              </div>
            </a>
          </li>
          <li>
            <a href="#" className="flex items-center p-3 rounded-lg hover:bg-slate-50 transition-colors">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-green-100 text-green-700 flex items-center justify-center">
                <i className="fas fa-chart-simple"></i>
              </div>
              <div className="ml-3">
                <h4 className="text-sm font-medium text-slate-900">Pareto Chart Analysis</h4>
                <p className="text-xs text-slate-500">Identify the vital few causes that need attention</p>
              </div>
            </a>
          </li>
          <li>
            <a href="#" className="flex items-center p-3 rounded-lg hover:bg-slate-50 transition-colors">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/20 text-primary flex items-center justify-center">
                <i className="fas fa-arrows-spin"></i>
              </div>
              <div className="ml-3">
                <h4 className="text-sm font-medium text-slate-900">PDCA Cycle Template</h4>
                <p className="text-xs text-slate-500">Plan-Do-Check-Act methodology for continuous improvement</p>
              </div>
            </a>
          </li>
        </ul>
      </Card>
    </div>
  );
}
