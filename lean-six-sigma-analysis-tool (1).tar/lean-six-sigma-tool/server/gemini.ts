import { GoogleGenerativeAI } from "@google/generative-ai";
import { AnalysisFormData } from "../client/src/hooks/use-analysis-form";

// Initialize Google Generative AI client with API key from environment variables
const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY || "placeholder-api-key-for-example");

// Log initialize message
console.log("Initializing Google Generative AI with provided API key");

// Generate the standard mode prompt (unknown root cause)
function generateStandardPrompt(formData: AnalysisFormData): string {
  return `You are an expert Lean Six Sigma consultant specializing in root cause analysis. Your task is to apply the 5 Whys methodology to the provided problem, identify the underlying root cause(s), and propose comprehensive, actionable solutions.

**Input Data:**
Problem: [${formData.problemStatement}]
When: [${formData.whenObserved}]
Where: [${formData.whereObserved}]
What are the Impacts: [${formData.impacts}]
Contributing Factors: [${formData.contributingFactors || 'None'}]

**Analysis Instructions:**
1. **5 Whys Chain:** Start with the problem statement and ask "Why?" repeatedly (minimum 3 levels, extend as needed) to build a logical cause-and-effect chain. Each "Why" should logically lead to the next answer, avoiding leaps in logic.
2. **Focus:** Frame "Why" questions around process failures, system design, training gaps, or environmental factors, not individual blame.
3. **Fact-Based:** Ground answers in facts, observations, and data. If data is missing, note it as a required action item.
4. **Root Cause Identification:** Continue asking "Why?" until an actionable root cause is identified—one that, if corrected, would prevent the problem from recurring. This is often a systemic issue.
5. **Test the Root Cause:** Use the "So What?" test (If this root cause is fixed, will the problem be resolved?) and reverse logic to validate the chain.

**Solution Generation Instructions:**
1. **Brainstorm Solutions:** Propose multiple potential solutions directly addressing the identified root cause(s). Focus on preventing recurrence.
2. **Evaluate Solutions:** Consider effectiveness, feasibility (resources: time, money, personnel), impact, sustainability, and risk for each proposed solution.
3. **Select Best Solution(s):** Recommend the most impactful, feasible, and sustainable solution(s). A combination of short-term and long-term actions may be appropriate.

**Output Requirements:**
Generate your response in JSON format with the following structure:
{
  "problemStatement": "reiterated problem statement",
  "whys": [
    { "question": "Why did the problem occur?", "answer": "Answer to first why" },
    { "question": "Why did that happen?", "answer": "Answer to second why" },
    ...
  ],
  "rootCause": "clearly stated root cause",
  "solutions": ["solution 1", "solution 2", ...],
  "actionPlan": [
    { 
      "action": "specific action", 
      "responsible": "responsible role/team", 
      "timeline": "realistic timeline", 
      "resources": "required resources", 
      "measurement": "effectiveness measurement" 
    },
    ...
  ]
}

**Quantification:** Where possible, include data (frequency, magnitude, cost) to make the problem and impact tangible.
**No Blame Culture:** Ensure the analysis emphasizes process and system flaws, not individual mistakes.`;
}

// Generate the advanced mode prompt (known root cause)
function generateAdvancedPrompt(formData: AnalysisFormData): string {
  return `You are an expert Lean Six Sigma consultant specializing in root cause analysis. Your task is to construct a realistic and logical 5 Whys chain that leads to the provided known root cause for the given problem, and then propose comprehensive, actionable solutions.

**Input Data:**
Problem: [${formData.problemStatement}]
When: [${formData.whenObserved}]
Where: [${formData.whereObserved}]
What are the Impacts: [${formData.impacts}]
Known Root Cause: [${formData.knownRootCause}]

**Analysis Instructions:**
1. **5 Whys Chain Construction:** Start with the problem statement. Work backward or forward to construct a logical "Why" chain (minimum 3 levels, extend as needed) that naturally and professionally leads to the specified "Known Root Cause."
2. **Logical Progression:** Ensure each "Why" logically leads to the next answer, avoiding forced connections or illogical leaps.
3. **Focus:** Frame "Why" questions around process failures, system design, training gaps, or environmental factors, not individual blame.
4. **Fact-Based:** Ground answers in plausible facts, observations, and data. If data is missing, suggest what information would be needed to validate.
5. **Test the Chain:** Validate the constructed "Why" chain using the "So What?" test and reverse logic to ensure it makes sense and realistically culminates in the known root cause.

**Solution Generation Instructions:**
1. **Brainstorm Solutions:** Propose multiple potential solutions directly addressing the "Known Root Cause." Focus on preventing recurrence.
2. **Evaluate Solutions:** Consider effectiveness, feasibility (resources: time, money, personnel), impact, sustainability, and risk for each proposed solution.
3. **Select Best Solution(s):** Recommend the most impactful, feasible, and sustainable solution(s). A combination of short-term and long-term actions may be appropriate.

**Output Requirements:**
Generate your response in JSON format with the following structure:
{
  "problemStatement": "reiterated problem statement",
  "whys": [
    { "question": "Why did the problem occur?", "answer": "Answer to first why" },
    { "question": "Why did that happen?", "answer": "Answer to second why" },
    ...
  ],
  "rootCause": "the known root cause",
  "solutions": ["solution 1", "solution 2", ...],
  "actionPlan": [
    { 
      "action": "specific action", 
      "responsible": "responsible role/team", 
      "timeline": "realistic timeline", 
      "resources": "required resources", 
      "measurement": "effectiveness measurement" 
    },
    ...
  ]
}

**Quantification:** Where possible, suggest what data (frequency, magnitude, cost) would be needed to support the problem and impact.
**No Blame Culture:** Ensure the analysis emphasizes process and system flaws, not individual mistakes.`;
}

// Main function to generate the analysis
export async function generateLeanSixSigmaAnalysis(formData: AnalysisFormData) {
  try {
    // Determine which prompt to use based on the mode
    const prompt = formData.mode === 'standard' 
      ? generateStandardPrompt(formData) 
      : generateAdvancedPrompt(formData);

    // Create a model instance with the Gemini model
    // Use the model name "gemini-pro" which is the standard model name
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });

    // Call Google Gemini API
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    if (!text) {
      throw new Error("No content returned from Google Gemini");
    }

    // Try to parse the response as JSON
    try {
      return JSON.parse(text);
    } catch (parseError) {
      console.error("Error parsing JSON response:", parseError);
      
      // If the response isn't valid JSON, try to extract JSON from the text
      // This is a fallback in case Gemini wraps the JSON in markdown or other text
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      throw new Error("Failed to parse response from Gemini as JSON");
    }
  } catch (error) {
    console.error("Error calling Google Gemini:", error);
    throw new Error(error instanceof Error ? error.message : "Failed to generate analysis");
  }
}