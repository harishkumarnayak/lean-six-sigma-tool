import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useState, useRef } from "react";

interface AnalysisResultsProps {
  results: any;
}

export default function AnalysisResults({ results }: AnalysisResultsProps) {
  const [copiedState, setCopiedState] = useState(false);
  const resultsRef = useRef<HTMLDivElement>(null);

  // Function to copy results to clipboard
  const copyToClipboard = () => {
    if (resultsRef.current) {
      // Create a range and select the content
      const range = document.createRange();
      range.selectNode(resultsRef.current);
      window.getSelection()?.removeAllRanges();
      window.getSelection()?.addRange(range);
      
      // Copy the selected content
      document.execCommand('copy');
      
      // Clear the selection
      window.getSelection()?.removeAllRanges();
      
      // Show feedback
      setCopiedState(true);
      setTimeout(() => setCopiedState(false), 2000);
    }
  };

  // Function to download results as a text file
  const downloadResults = () => {
    if (resultsRef.current) {
      const text = resultsRef.current.innerText;
      const blob = new Blob([text], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'root-cause-analysis.txt';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  // Function to print results
  const printResults = () => {
    window.print();
  };

  // Helper function to render the table based on the 5 Whys analysis
  const renderWhysTable = () => {
    if (!results || !results.whys || !Array.isArray(results.whys)) {
      return null;
    }

    return (
      <table className="w-full border-collapse mb-6">
        <thead>
          <tr>
            <th className="border border-slate-300 bg-slate-50 p-2 text-left">Why?</th>
            <th className="border border-slate-300 bg-slate-50 p-2 text-left">Answer</th>
          </tr>
        </thead>
        <tbody>
          {results.whys.map((why: any, index: number) => (
            <tr key={index}>
              <td className="border border-slate-300 p-2">{why.question}</td>
              <td className="border border-slate-300 p-2">{why.answer}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  // Helper function to render the action plan table
  const renderActionPlanTable = () => {
    if (!results || !results.actionPlan || !Array.isArray(results.actionPlan)) {
      return null;
    }

    return (
      <table className="w-full border-collapse mb-6">
        <thead>
          <tr>
            <th className="border border-slate-300 bg-slate-50 p-2 text-left">Action</th>
            <th className="border border-slate-300 bg-slate-50 p-2 text-left">Responsible</th>
            <th className="border border-slate-300 bg-slate-50 p-2 text-left">Timeline</th>
            <th className="border border-slate-300 bg-slate-50 p-2 text-left">Resources</th>
            <th className="border border-slate-300 bg-slate-50 p-2 text-left">Measurement</th>
          </tr>
        </thead>
        <tbody>
          {results.actionPlan.map((action: any, index: number) => (
            <tr key={index}>
              <td className="border border-slate-300 p-2">{action.action}</td>
              <td className="border border-slate-300 p-2">{action.responsible}</td>
              <td className="border border-slate-300 p-2">{action.timeline}</td>
              <td className="border border-slate-300 p-2">{action.resources}</td>
              <td className="border border-slate-300 p-2">{action.measurement}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  // Helper function to render the solutions list
  const renderSolutionsList = () => {
    if (!results || !results.solutions || !Array.isArray(results.solutions)) {
      return null;
    }

    return (
      <ol className="list-decimal pl-5 mb-6 space-y-2">
        {results.solutions.map((solution: string, index: number) => (
          <li key={index}>{solution}</li>
        ))}
      </ol>
    );
  };

  return (
    <Card className="bg-white rounded-lg shadow-sm overflow-hidden">
      <CardHeader className="bg-primary text-white px-6 py-4 flex items-center justify-between">
        <h3 className="text-xl font-semibold">Analysis Results</h3>
        <div className="flex items-center space-x-2">
          <Button 
            onClick={copyToClipboard} 
            variant="secondary" 
            className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white"
          >
            <i className={`fas ${copiedState ? 'fa-check' : 'fa-copy'} mr-1.5`}></i> 
            {copiedState ? 'Copied!' : 'Copy'}
          </Button>
          <Button 
            onClick={downloadResults} 
            variant="secondary" 
            className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white"
          >
            <i className="fas fa-download mr-1.5"></i> Download
          </Button>
          <Button 
            onClick={printResults} 
            variant="secondary" 
            className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white"
          >
            <i className="fas fa-print mr-1.5"></i> Print
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="p-6 prose max-w-none" ref={resultsRef}>
        <h2 className="text-primary font-bold text-2xl mb-4">5 Whys Root Cause Analysis</h2>
        
        <h3 className="text-primary font-semibold text-xl mt-6 mb-2">Problem Statement</h3>
        <p>{results.problemStatement}</p>
        
        <h3 className="text-primary font-semibold text-xl mt-6 mb-2">5 Whys Analysis</h3>
        {renderWhysTable()}
        
        <h3 className="text-primary font-semibold text-xl mt-6 mb-2">Root Cause</h3>
        <p>{results.rootCause}</p>
        
        <h3 className="text-primary font-semibold text-xl mt-6 mb-2">Proposed Solutions</h3>
        {renderSolutionsList()}
        
        <h3 className="text-primary font-semibold text-xl mt-6 mb-2">Action Plan</h3>
        {renderActionPlanTable()}
      </CardContent>
    </Card>
  );
}
