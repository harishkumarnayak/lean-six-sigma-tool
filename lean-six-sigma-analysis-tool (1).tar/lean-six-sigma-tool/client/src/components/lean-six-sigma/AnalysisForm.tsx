import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { AnalysisFormData } from "@/hooks/use-analysis-form";

interface AnalysisFormProps {
  formData: AnalysisFormData;
  onModeChange: (mode: 'standard' | 'advanced') => void;
  onInputChange: (field: keyof AnalysisFormData, value: string) => void;
  onSubmit: () => void;
  onReset: () => void;
}

export default function AnalysisForm({ 
  formData, 
  onModeChange, 
  onInputChange, 
  onSubmit, 
  onReset 
}: AnalysisFormProps) {
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Handle mode change
  const handleModeChange = (mode: 'standard' | 'advanced') => {
    onModeChange(mode);
    setErrors({});
  };

  // Validate form
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    const requiredFields: (keyof AnalysisFormData)[] = ['problemStatement', 'whenObserved', 'whereObserved', 'impacts'];
    
    if (formData.mode === 'advanced') {
      requiredFields.push('knownRootCause');
    }
    
    requiredFields.forEach(field => {
      if (!formData[field] || formData[field].trim() === '') {
        newErrors[field] = 'This field is required';
      }
    });
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit();
    }
  };

  // Reset form and errors
  const handleReset = () => {
    onReset();
    setErrors({});
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-xl font-semibold text-primary mb-4">How to Use</h3>
      <p className="text-slate-700 mb-6">
        To get the most out of this template, provide the following information about your problem. Be concise and specific.
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Mode selection */}
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
          <h4 className="text-lg font-medium text-slate-700 mb-3">Select Analysis Mode</h4>
          <div className="flex flex-col sm:flex-row gap-4">
            <label className="relative flex items-start cursor-pointer flex-1">
              <input 
                type="radio" 
                name="mode" 
                className="sr-only peer" 
                checked={formData.mode === 'standard'}
                onChange={() => handleModeChange('standard')}
              />
              <div className="w-full p-4 rounded-lg border-2 peer-checked:border-primary peer-checked:bg-primary/10 transition-colors border-slate-300">
                <div className="flex items-start">
                  <div className="mr-3 flex-shrink-0 w-6 h-6 rounded-full border-2 border-slate-300 peer-checked:border-primary flex items-center justify-center">
                    {formData.mode === 'standard' && (
                      <div className="w-3 h-3 bg-primary rounded-full"></div>
                    )}
                  </div>
                  <div>
                    <span className="block text-base font-medium text-slate-900">Standard Mode</span>
                    <span className="block text-sm text-slate-600">Unknown Root Cause (Default)</span>
                  </div>
                </div>
              </div>
            </label>
            
            <label className="relative flex items-start cursor-pointer flex-1">
              <input 
                type="radio" 
                name="mode" 
                className="sr-only peer" 
                checked={formData.mode === 'advanced'}
                onChange={() => handleModeChange('advanced')}
              />
              <div className="w-full p-4 rounded-lg border-2 peer-checked:border-primary peer-checked:bg-primary/10 transition-colors border-slate-300">
                <div className="flex items-start">
                  <div className="mr-3 flex-shrink-0 w-6 h-6 rounded-full border-2 border-slate-300 peer-checked:border-primary flex items-center justify-center">
                    {formData.mode === 'advanced' && (
                      <div className="w-3 h-3 bg-primary rounded-full"></div>
                    )}
                  </div>
                  <div>
                    <span className="block text-base font-medium text-slate-900">Advanced Mode</span>
                    <span className="block text-sm text-slate-600">Known Root Cause (Optional)</span>
                  </div>
                </div>
              </div>
            </label>
          </div>
        </div>

        {/* Input fields */}
        <div>
          <label htmlFor="problemStatement" className="block text-sm font-medium text-slate-700 mb-1">
            Problem Statement <span className="text-red-500">*</span>
          </label>
          <Textarea
            id="problemStatement"
            rows={2}
            placeholder="Example: Machine downtime increased by 30% last month on Line-3."
            value={formData.problemStatement}
            onChange={(e) => onInputChange('problemStatement', e.target.value)}
            className={`w-full ${errors.problemStatement ? 'border-red-500' : 'border-slate-300'}`}
          />
          {errors.problemStatement && (
            <p className="text-red-500 text-xs mt-1">{errors.problemStatement}</p>
          )}
          <p className="mt-1 text-xs text-slate-500">Be specific about the issue and include measurable details when possible.</p>
        </div>

        <div>
          <label htmlFor="whenObserved" className="block text-sm font-medium text-slate-700 mb-1">
            When Observed <span className="text-red-500">*</span>
          </label>
          <Input
            id="whenObserved"
            placeholder="Example: Observed during night shifts, mostly on high-speed batches."
            value={formData.whenObserved}
            onChange={(e) => onInputChange('whenObserved', e.target.value)}
            className={`w-full ${errors.whenObserved ? 'border-red-500' : 'border-slate-300'}`}
          />
          {errors.whenObserved && (
            <p className="text-red-500 text-xs mt-1">{errors.whenObserved}</p>
          )}
        </div>

        <div>
          <label htmlFor="whereObserved" className="block text-sm font-medium text-slate-700 mb-1">
            Where Observed <span className="text-red-500">*</span>
          </label>
          <Input
            id="whereObserved"
            placeholder="Example: Observed on Blister Packing Machine, Line-3, sealing station."
            value={formData.whereObserved}
            onChange={(e) => onInputChange('whereObserved', e.target.value)}
            className={`w-full ${errors.whereObserved ? 'border-red-500' : 'border-slate-300'}`}
          />
          {errors.whereObserved && (
            <p className="text-red-500 text-xs mt-1">{errors.whereObserved}</p>
          )}
        </div>

        <div>
          <label htmlFor="impacts" className="block text-sm font-medium text-slate-700 mb-1">
            What are the Impacts <span className="text-red-500">*</span>
          </label>
          <Textarea
            id="impacts"
            rows={2}
            placeholder="Example: Caused 6 hours of downtime, rejected 2,000 blisters, resulting in ₹50,000 in losses."
            value={formData.impacts}
            onChange={(e) => onInputChange('impacts', e.target.value)}
            className={`w-full ${errors.impacts ? 'border-red-500' : 'border-slate-300'}`}
          />
          {errors.impacts && (
            <p className="text-red-500 text-xs mt-1">{errors.impacts}</p>
          )}
          <p className="mt-1 text-xs text-slate-500">Include quantifiable impacts like time, costs, quality issues, or other metrics.</p>
        </div>

        <div>
          <label htmlFor="contributingFactors" className="block text-sm font-medium text-slate-700 mb-1">
            Known Contributing Factors <span className="text-slate-500 font-normal">(Optional)</span>
          </label>
          <Textarea
            id="contributingFactors"
            rows={2}
            placeholder="Example: Temperature fluctuation, operator changeover, sensor error."
            value={formData.contributingFactors}
            onChange={(e) => onInputChange('contributingFactors', e.target.value)}
            className="w-full border-slate-300"
          />
        </div>

        {/* Known Root Cause - Only visible in advanced mode */}
        {formData.mode === 'advanced' && (
          <div>
            <label htmlFor="knownRootCause" className="block text-sm font-medium text-slate-700 mb-1">
              Known Root Cause <span className="text-red-500">*</span>
            </label>
            <Textarea
              id="knownRootCause"
              rows={2}
              placeholder="Example: Lack of standardized maintenance procedure for the sealing station."
              value={formData.knownRootCause}
              onChange={(e) => onInputChange('knownRootCause', e.target.value)}
              className={`w-full ${errors.knownRootCause ? 'border-red-500' : 'border-slate-300'}`}
            />
            {errors.knownRootCause && (
              <p className="text-red-500 text-xs mt-1">{errors.knownRootCause}</p>
            )}
            <p className="mt-1 text-xs text-slate-500">Enter the root cause that you've already identified. The AI will build a logical analysis chain to this cause.</p>
          </div>
        )}

        <div className="flex justify-end pt-4">
          <Button
            type="button"
            onClick={handleReset}
            variant="outline"
            className="mr-3 text-slate-700 bg-white hover:bg-slate-50"
          >
            <i className="fas fa-redo mr-2"></i> Reset Form
          </Button>
          <Button
            type="submit"
            className="bg-primary hover:bg-primary/90 text-white"
          >
            <i className="fas fa-magic mr-2"></i> Generate Analysis
          </Button>
        </div>
      </form>
    </div>
  );
}
