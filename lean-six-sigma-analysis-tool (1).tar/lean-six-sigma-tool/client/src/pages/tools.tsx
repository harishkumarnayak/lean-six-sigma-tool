import { useState } from "react";
import AnalysisForm from "@/components/lean-six-sigma/AnalysisForm";
import AnalysisResults from "@/components/lean-six-sigma/AnalysisResults";
import InfoSidebar from "@/components/lean-six-sigma/InfoSidebar";
import LoadingIndicator from "@/components/lean-six-sigma/LoadingIndicator";
import ErrorMessage from "@/components/lean-six-sigma/ErrorMessage";
import { useAnalysisForm } from "@/hooks/use-analysis-form";

export default function Tools() {
  const { 
    formData, 
    isLoading, 
    isError,
    errorMessage, 
    analysisResults,
    handleModeChange,
    handleInputChange,
    handleSubmit,
    resetForm,
    retrySubmission
  } = useAnalysisForm();

  return (
    <div className="bg-slate-50 text-slate-800 min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-primary">Lean Six Sigma Analysis Tools</h1>
          <p className="text-slate-600 mt-2">Professional tools for process improvement and problem-solving</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Tool Header */}
        <div className="mb-10">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-primary mb-2">5 Whys Root Cause Analysis & Solution Generator</h2>
              <div className="flex items-center space-x-2 text-sm text-slate-600">
                <span className="flex items-center"><i className="fas fa-chart-line mr-1"></i> Powered by Google Gemini AI</span>
                <span>•</span>
                <span className="flex items-center"><i className="fas fa-clock mr-1"></i> 5-10 min analysis</span>
              </div>
            </div>
            
            {/* Top right tool icons */}
            <div className="flex space-x-3 mt-4 md:mt-0">
              <button className="inline-flex items-center text-primary hover:text-primary/90 transition-colors">
                <i className="fas fa-question-circle text-lg"></i>
                <span className="ml-1 text-sm font-medium">Help</span>
              </button>
              <button className="inline-flex items-center text-primary hover:text-primary/90 transition-colors">
                <i className="fas fa-info-circle text-lg"></i>
                <span className="ml-1 text-sm font-medium">About</span>
              </button>
            </div>
          </div>

          {/* Tool description */}
          <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <div className="flex items-start">
              {/* Diagram for larger screens */}
              <div className="hidden md:block mr-6 w-48 flex-shrink-0">
                <svg viewBox="0 0 300 300" className="rounded-lg shadow-sm">
                  <rect width="300" height="300" fill="#f0fdfa" rx="8" />
                  <circle cx="150" cy="60" r="30" fill="#14b8a6" />
                  <text x="150" y="65" fontSize="14" textAnchor="middle" fill="white">Problem</text>
                  <line x1="150" y1="90" x2="150" y2="110" stroke="#14b8a6" strokeWidth="2" />
                  <text x="160" y="105" fontSize="12" fill="#134e4a">Why?</text>
                  <circle cx="150" cy="130" r="25" fill="#0ea5e9" />
                  <text x="150" y="135" fontSize="12" textAnchor="middle" fill="white">Cause 1</text>
                  <line x1="150" y1="155" x2="150" y2="175" stroke="#0ea5e9" strokeWidth="2" />
                  <text x="160" y="170" fontSize="12" fill="#0c4a6e">Why?</text>
                  <circle cx="150" cy="195" r="25" fill="#10b981" />
                  <text x="150" y="200" fontSize="12" textAnchor="middle" fill="white">Cause 2</text>
                  <line x1="150" y1="220" x2="150" y2="240" stroke="#10b981" strokeWidth="2" />
                  <text x="160" y="235" fontSize="12" fill="#064e3b">Why?</text>
                  <circle cx="150" cy="260" r="25" fill="#047857" />
                  <text x="150" y="265" fontSize="12" textAnchor="middle" fill="white">Root Cause</text>
                </svg>
              </div>
              
              <div>
                <p className="text-slate-700 mb-4">
                  Unlock the true causes of your problems and implement lasting solutions with this Lean Six Sigma 5 Whys AI prompt template. Designed for efficiency and accuracy, it guides you through a structured root cause analysis, generating actionable insights and comprehensive action plans. Perfect for manufacturing, operations, service, TPM, and quality teams seeking to improve processes and prevent recurrence.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                    <i className="fas fa-industry mr-1"></i> Manufacturing
                  </span>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                    <i className="fas fa-cogs mr-1"></i> Operations
                  </span>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                    <i className="fas fa-concierge-bell mr-1"></i> Service
                  </span>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                    <i className="fas fa-tasks mr-1"></i> Quality
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-12 gap-8">
          {/* Input Form */}
          <div className="md:col-span-7 lg:col-span-8">
            <AnalysisForm 
              formData={formData}
              onModeChange={handleModeChange}
              onInputChange={handleInputChange}
              onSubmit={handleSubmit}
              onReset={resetForm}
            />
          </div>

          {/* Info Sidebar */}
          <div className="md:col-span-5 lg:col-span-4">
            <InfoSidebar />
          </div>
        </div>

        {/* Results Section */}
        {analysisResults && !isLoading && !isError && (
          <div className="mt-10">
            <AnalysisResults results={analysisResults} />
          </div>
        )}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="mt-10">
            <LoadingIndicator />
          </div>
        )}

        {/* Error Message */}
        {isError && (
          <div className="mt-10">
            <ErrorMessage 
              message={errorMessage} 
              onRetry={retrySubmission} 
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8 mt-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h4 className="text-lg font-semibold mb-2">Lean Six Sigma Tools</h4>
              <p className="text-slate-300 text-sm">Powered by advanced AI for process improvement</p>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              <a href="#" className="text-slate-300 hover:text-white text-sm">Privacy Policy</a>
              <a href="#" className="text-slate-300 hover:text-white text-sm">Terms of Service</a>
              <a href="#" className="text-slate-300 hover:text-white text-sm">Contact Support</a>
            </div>
          </div>
          <div className="mt-8 pt-4 border-t border-slate-700 text-center text-slate-400 text-xs">
            &copy; {new Date().getFullYear()} Lean Six Sigma Tools. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
