import { GoogleGenerativeAI } from "@google/generative-ai";

// Get API key from environment variable
const apiKey = process.env.GOOGLE_API_KEY || "";

// Function to list available models
async function listAvailableModels() {
  try {
    console.log("Attempting to list all available Google Gemini models...");
    
    // Create the client
    const genAI = new GoogleGenerativeAI(apiKey);
    
    // This is a workaround since listModels() might not be directly available
    // We'll try to construct the model with different names and see which one works
    const modelOptions = [
      "gemini-pro",
      "gemini-1.0-pro",
      "gemini-1.5-pro",
      "gemini-pro-latest"
    ];
    
    console.log("Testing the following model options:", modelOptions);
    
    for (const modelName of modelOptions) {
      try {
        console.log(`Trying to initialize model: ${modelName}`);
        const model = genAI.getGenerativeModel({ model: modelName });
        
        // Test if we can generate content with this model
        const result = await model.generateContent("Hello world");
        console.log(`SUCCESS! Model ${modelName} is working. Response:`, result.response.text());
        
        return modelName; // Return the first working model name
      } catch (error) {
        console.log(`Model ${modelName} failed:`, error.message);
      }
    }
    
    console.log("No models were working with the current API key and version.");
    return null;
  } catch (error) {
    console.error("Failed to list models:", error);
    return null;
  }
}

// Export for use in other modules
export { listAvailableModels };

// Run immediately if this file is executed directly
if (require.main === module) {
  listAvailableModels().then(workingModel => {
    if (workingModel) {
      console.log(`\n\nRECOMMENDATION: Use "${workingModel}" as your model name in gemini.ts`);
    } else {
      console.log("\n\nNo working models found. Please check your API key and permissions.");
    }
  });
}